import { Phone } from "lucide-react";
import { Navbar, Hero, Services, StickyCTA, Footer } from "./components/Landing";

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <Services />

        {/* About Section - Split Layout */}
        <section id="about" className="py-32 bg-brand-secondary">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
              <div className="relative">
                <div className="aspect-square rounded-[3rem] overflow-hidden glass">
                  <img
                    src="https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?auto=format&fit=crop&q=80&w=1000"
                    className="w-full h-full object-cover opacity-80"
                    alt="Modern HVAC System"
                  />
                </div>
                <div className="absolute -bottom-10 -right-10 glass p-8 rounded-3xl hidden md:block animate-float">
                  <p className="text-4xl font-display font-bold text-brand-highlight">25+</p>
                  <p className="text-sm font-bold text-brand-muted uppercase tracking-widest">Years Experience</p>
                </div>
              </div>

              <div>
                <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tighter mb-8">Built on Trust, <br />Driven by Tech.</h2>
                <div className="space-y-6 text-xl text-brand-muted leading-relaxed">
                  <p>
                    ___COMPANY_NAME___ was founded on a simple principle: home maintenance should be as sophisticated as the homes it serves. We combine old-world craftsmanship with modern diagnostic technology.
                  </p>
                  <p>
                    Our technicians are not just repairmen; they are comfort engineers trained in the latest sustainable climate technologies and high-efficiency plumbing systems.
                  </p>
                </div>
                <div className="mt-12 grid grid-cols-2 gap-8">
                  <div>
                    <p className="text-3xl font-display font-bold text-brand-accent">15k+</p>
                    <p className="text-sm font-bold text-brand-muted uppercase tracking-widest">Homes Served</p>
                  </div>
                  <div>
                    <p className="text-3xl font-display font-bold text-brand-accent">4.9/5</p>
                    <p className="text-sm font-bold text-brand-muted uppercase tracking-widest">Average Rating</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-32">
          <div className="max-w-7xl mx-auto px-6">
            <div className="glass rounded-[3rem] p-12 md:p-20 relative overflow-hidden bg-brand-secondary/50">
              <div className="absolute top-0 right-0 w-1/3 h-full bg-brand-highlight/5 blur-[120px] rounded-full" />

              <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-20">
                <div>
                  <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tighter mb-8 text-brand-accent">Ready to Code Your Comfort?</h2>
                  <p className="text-xl text-brand-muted mb-12">Get a precision quote for your next project or schedule an immediate service visit with ___COMPANY_NAME___.</p>

                  <div className="space-y-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full glass flex items-center justify-center text-brand-highlight">
                        <Phone size={20} />
                      </div>
                      <a href="tel:___PHONE_RAW___">
                        <p className="text-sm font-bold text-brand-muted uppercase tracking-widest">Call Anytime</p>
                        <p className="text-xl font-bold text-brand-accent">___PHONE___</p>
                      </a>
                    </div>
                  </div>
                </div>

                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <input type="text" placeholder="Full Name" className="w-full glass px-6 py-4 rounded-2xl outline-none focus:border-brand-highlight transition-colors text-brand-accent placeholder:text-brand-muted/50" />
                    <input type="email" placeholder="Email Address" className="w-full glass px-6 py-4 rounded-2xl outline-none focus:border-brand-highlight transition-colors text-brand-accent placeholder:text-brand-muted/50" />
                  </div>
                  <select className="w-full glass px-6 py-4 rounded-2xl outline-none focus:border-brand-highlight transition-colors appearance-none text-brand-muted/50">
                    <option>Select Service</option>
                    <option>HVAC Repair</option>
                    <option>New Installation</option>
                    <option>Plumbing Emergency</option>
                    <option>Maintenance Plan</option>
                  </select>
                  <textarea placeholder="Tell us about your project..." rows={4} className="w-full glass px-6 py-4 rounded-2xl outline-none focus:border-brand-highlight transition-colors text-brand-accent placeholder:text-brand-muted/50"></textarea>
                  <button className="w-full bg-brand-accent text-white py-5 rounded-2xl font-bold text-lg hover:bg-brand-highlight transition-all shadow-lg shadow-brand-accent/10">
                    Send Request
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <StickyCTA />
    </div>
  );
}

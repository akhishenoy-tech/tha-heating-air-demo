import { motion } from "motion/react";
import { Phone, Menu, X, Droplets, Wind, ShieldCheck } from "lucide-react";
import { useState, useEffect } from "react";

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? "py-4" : "py-8"}`}>
      <div className="max-w-7xl mx-auto px-6">
        <div className={`flex items-center justify-between rounded-full px-6 py-3 transition-all duration-500 ${isScrolled ? "glass shadow-2xl" : "bg-transparent"}`}>
          <div className="flex items-center gap-2">
            {"___LOGO_URL___" !== "" ? (
              <img src="___LOGO_URL___" className="h-8 w-auto object-contain" alt="___COMPANY_NAME___ Logo" />
            ) : (
              <div className="w-10 h-10 bg-brand-accent rounded-xl flex items-center justify-center">
                <Droplets className="text-white size-6" />
              </div>
            )}
            <span className="font-display font-bold text-xl tracking-tighter">___COMPANY_NAME___</span>
          </div>

          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-brand-muted">
            <a href="#services" className="hover:text-brand-highlight transition-colors">Services</a>
            <a href="#about" className="hover:text-brand-highlight transition-colors">About</a>
            <a href="#reviews" className="hover:text-brand-highlight transition-colors">Reviews</a>
            <a href="#contact" className="hover:text-brand-highlight transition-colors">Contact</a>
          </div>

          <div className="flex items-center gap-4">
            <a href="tel:___PHONE_RAW___" className="hidden sm:flex items-center gap-2 bg-brand-accent text-white px-5 py-2.5 rounded-full text-sm font-bold hover:bg-brand-highlight transition-all hover:scale-105 active:scale-95">
              <Phone size={16} />
              <span>___PHONE___</span>
            </a>
            <button
              className="md:hidden text-brand-accent"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-6 right-6 mt-4 glass rounded-3xl p-8 md:hidden"
        >
          <div className="flex flex-col gap-6 text-lg font-medium">
            <a href="#services" onClick={() => setIsMobileMenuOpen(false)}>Services</a>
            <a href="#about" onClick={() => setIsMobileMenuOpen(false)}>About</a>
            <a href="#reviews" onClick={() => setIsMobileMenuOpen(false)}>Reviews</a>
            <a href="#contact" onClick={() => setIsMobileMenuOpen(false)}>Contact</a>
            <hr className="border-slate-200" />
            <a href="tel:___PHONE_RAW___" className="flex items-center justify-center gap-2 bg-brand-highlight text-white py-4 rounded-2xl font-bold">
              <Phone size={20} />
              Emergency Service
            </a>
          </div>
        </motion.div>
      )}
    </nav>
  );
};

export const Hero = () => {
  return (
    <section className="relative h-screen min-h-[800px] flex items-center overflow-hidden">
      {/* Cinematic Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="___HERO_IMAGE___"
          className="w-full h-full object-cover opacity-60 scale-105"
          alt="___COMPANY_NAME___"
        />
        <div className="absolute inset-0 bg-linear-to-b from-brand-primary/95 via-brand-primary/40 to-brand-primary" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full pt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-3xl"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 animate-float">
            <ShieldCheck className="text-brand-highlight size-4" />
            <span className="text-xs font-bold tracking-widest uppercase text-brand-muted">___TRUST_BADGE___</span>
          </div>

          <h1 className="font-display text-6xl md:text-8xl font-bold leading-[0.9] tracking-tighter mb-8 text-gradient">
            ___HERO_TITLE___
          </h1>

          <p className="text-xl md:text-2xl text-brand-muted leading-relaxed mb-12 max-w-2xl">
            ___HERO_SUBTITLE___
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-brand-highlight text-white px-10 py-5 rounded-full font-bold text-lg hover:scale-105 transition-transform shadow-[0_10px_30px_rgba(37,99,235,0.2)]">
              Schedule Service
            </button>
            <button className="glass px-10 py-5 rounded-full font-bold text-lg hover:bg-slate-100 transition-all text-brand-accent">
              View Our Work
            </button>
          </div>
        </motion.div>
      </div>

      {/* Trust Badges */}
      {(() => {
        const trustedBrands = ___TRUSTED_BRANDS_JSON___;
        const brandsArray = Array.isArray(trustedBrands) ? trustedBrands : [];
        if (brandsArray.length === 0) return null;

        return (
          <div className="absolute bottom-12 left-0 right-0 z-10 hidden lg:block">
            <div className="max-w-7xl mx-auto px-6">
              <div className="flex items-center gap-12 text-brand-muted/40">
                <span className="text-sm font-bold uppercase tracking-widest">Trusted By</span>
                <div className="flex items-center gap-12 opacity-40 grayscale flex-wrap">
                  {brandsArray.map((brand: string, i: number) => (
                    <span key={i} className="text-2xl font-display font-bold italic">{brand}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
      })()}
    </section>
  );
};

export const Services = () => {
  const servicesData = ___SERVICES_JSON___;
  const services = Array.isArray(servicesData) ? servicesData : [
    { title: "Master Plumbing", desc: "From leak detection to full structure installations." },
    { title: "HVAC Engineering", desc: "Smart climate control systems for maximum efficiency." },
    { title: "Maintenance", desc: "Year-round preventive care for peace of mind." }
  ];

  return (
    <section id="services" className="py-32 max-w-7xl mx-auto px-6">
      <div className="mb-20">
        <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tighter mb-6">Mastery in Every Detail.</h2>
        <p className="text-xl text-brand-muted max-w-2xl">We don't just fix pipes and units. We engineer comfort and reliability into the DNA of your home.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {services.map((s: any, i: number) => (
          <motion.div
            key={i}
            whileHover={{ y: -10 }}
            className="relative group overflow-hidden rounded-[2.5rem] glass"
          >
            <div className="absolute inset-0 z-0">
              <img src={`/assets/${i % 2 === 0 ? 'water-tanks.jpg' : 'pipelines.jpg'}`} className="w-full h-full object-cover opacity-10 group-hover:opacity-20 transition-opacity duration-700" alt={s.title} />
              <div className="absolute inset-0 bg-linear-to-t from-brand-primary via-brand-primary/20 to-transparent" />
            </div>

            <div className="relative z-10 p-10 h-full flex flex-col justify-end min-h-[400px]">
              <div className="w-16 h-16 bg-brand-highlight/10 rounded-2xl flex items-center justify-center mb-6 text-brand-highlight group-hover:bg-brand-highlight group-hover:text-white transition-all duration-500">
                {i % 2 === 0 ? <Droplets className="size-8" /> : <Wind className="size-8" />}
              </div>
              <h3 className="text-3xl font-display font-bold mb-4">{s.title}</h3>
              <p className="text-brand-muted text-lg leading-relaxed">{s.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export const StickyCTA = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsVisible(window.scrollY > 400);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 100 }}
      animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 100 }}
      className="fixed bottom-8 left-0 right-0 z-50 px-6 pointer-events-none"
    >
      <div className="max-w-md mx-auto glass p-2 rounded-full flex items-center gap-2 pointer-events-auto shadow-2xl">
        <div className="flex-1 pl-6">
          <p className="text-xs font-bold text-brand-muted uppercase tracking-widest">Emergency Line</p>
          <p className="text-sm font-bold text-brand-accent">___PHONE___</p>
        </div>
        <button className="bg-brand-highlight text-white px-8 py-3 rounded-full font-bold text-sm hover:scale-105 transition-transform">
          Book Now
        </button>
      </div>
    </motion.div>
  );
};

export const Footer = () => {
  return (
    <footer className="bg-brand-secondary pt-32 pb-12 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-32">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-8">
              {"___LOGO_URL___" !== "" ? (
                <img src="___LOGO_URL___" className="h-8 w-auto object-contain" alt="___COMPANY_NAME___ Logo" />
              ) : (
                <div className="w-8 h-8 bg-brand-highlight rounded-lg flex items-center justify-center">
                  <Droplets className="text-white size-5" />
                </div>
              )}
              <span className="font-display font-bold text-xl tracking-tighter text-brand-accent">___COMPANY_NAME___</span>
            </div>
            <p className="text-2xl text-brand-muted font-display leading-tight max-w-md">
              The standard for premium home maintenance and engineering.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-sm uppercase tracking-widest text-brand-highlight">Navigation</h4>
            <ul className="space-y-4 text-brand-muted">
              <li><a href="#" className="hover:text-brand-accent transition-colors">Services</a></li>
              <li><a href="#" className="hover:text-brand-accent transition-colors">Maintenance Plans</a></li>
              <li><a href="#" className="hover:text-brand-accent transition-colors">Commercial</a></li>
              <li><a href="#" className="hover:text-brand-accent transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-sm uppercase tracking-widest text-brand-highlight">Legal</h4>
            <ul className="space-y-4 text-brand-muted">
              <li><a href="#" className="hover:text-brand-accent transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-brand-accent transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-brand-accent transition-colors">License Info</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-8 pt-12 border-t border-slate-200 text-brand-muted/40 text-sm">
          <p>© 2024 ___COMPANY_NAME___. All rights reserved.</p>
          <div className="flex items-center gap-8">
            <span className="hover:text-brand-accent cursor-pointer transition-colors">Instagram</span>
            <span className="hover:text-brand-accent cursor-pointer transition-colors">LinkedIn</span>
            <span className="hover:text-brand-accent cursor-pointer transition-colors">Twitter</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
